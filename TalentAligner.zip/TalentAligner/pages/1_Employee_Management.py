import streamlit as st
import pandas as pd
from data_manager import (
    add_employee, update_employee, delete_employee, 
    filter_employees, get_employee_by_id
)

def display_employee_form(employee=None):
    """Display form for adding or editing an employee"""
    # Initialize empty dictionary if no employee provided
    if employee is None:
        employee = {
            'employee_id': '',
            'name': '',
            'department': '',
            'job_title': '',
            'joining_date': '',
            'skills': [],
            'certifications': [],
            'experience': 0,
            'education': '',
            'projects': [],
            'performance_scores': [],
            'peer_reviews': ''
        }
    
    # Get departments list from session state
    departments = sorted(list(st.session_state.departments))
    
    # Get skills list from session state
    skills_list = sorted(list(st.session_state.skills))
    
    # Get certifications list from session state
    certifications_list = sorted(list(st.session_state.certifications))
    
    # Create form
    with st.form("employee_form"):
        st.subheader("Employee Information")
        
        # Basic Information
        col1, col2 = st.columns(2)
        
        with col1:
            name = st.text_input("Name", value=employee.get('name', ''))
            department = st.selectbox(
                "Department", 
                options=departments,
                index=departments.index(employee.get('department')) if employee.get('department') in departments else 0
            )
        
        with col2:
            job_title = st.text_input("Job Title", value=employee.get('job_title', ''))
            joining_date = st.date_input(
                "Joining Date", 
                value=pd.to_datetime(employee.get('joining_date')).date() if employee.get('joining_date') else pd.Timestamp.now().date()
            )
        
        # Skills and Certifications
        st.subheader("Skills and Qualifications")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Skills with multiselect and option to add new
            selected_skills = st.multiselect(
                "Skills", 
                options=skills_list, 
                default=employee.get('skills', []) if isinstance(employee.get('skills'), list) else []
            )
            
            new_skill = st.text_input("Add New Skill (Type and submit form)")
        
        with col2:
            # Certifications with multiselect and option to add new
            selected_certifications = st.multiselect(
                "Certifications", 
                options=certifications_list, 
                default=employee.get('certifications', []) if isinstance(employee.get('certifications'), list) else []
            )
            
            new_certification = st.text_input("Add New Certification (Type and submit form)")
        
        # Experience and Education
        st.subheader("Experience and Education")
        
        col1, col2 = st.columns(2)
        
        with col1:
            experience = st.number_input(
                "Years of Experience", 
                min_value=0.0, 
                max_value=50.0, 
                value=float(employee.get('experience', 0)),
                step=0.5
            )
        
        with col2:
            education = st.selectbox(
                "Highest Education", 
                options=["High School", "Associate's Degree", "Bachelor's Degree", "Master's Degree", "PhD", "Other"],
                index=["High School", "Associate's Degree", "Bachelor's Degree", "Master's Degree", "PhD", "Other"].index(employee.get('education')) if employee.get('education') in ["High School", "Associate's Degree", "Bachelor's Degree", "Master's Degree", "PhD", "Other"] else 0
            )
        
        # Projects and Performance
        st.subheader("Projects and Performance")
        
        projects = st.text_area(
            "Projects (comma separated)", 
            value=', '.join(employee.get('projects', [])) if isinstance(employee.get('projects'), list) else employee.get('projects', '')
        )
        
        peer_reviews = st.text_area(
            "Peer Reviews", 
            value=employee.get('peer_reviews', '')
        )
        
        # Submit button
        submit_button = st.form_submit_button("Save Employee")
        
        if submit_button:
            # Parse projects into list
            projects_list = [p.strip() for p in projects.split(',') if p.strip()]
            
            # Handle new skill if entered
            if new_skill and new_skill not in skills_list:
                st.session_state.skills.add(new_skill)
                selected_skills.append(new_skill)
                
            # Handle new certification if entered
            if new_certification and new_certification not in certifications_list:
                st.session_state.certifications.add(new_certification)
                selected_certifications.append(new_certification)
            
            # Create employee data dictionary
            employee_data = {
                'name': name,
                'department': department,
                'job_title': job_title,
                'joining_date': joining_date,
                'skills': selected_skills,
                'certifications': selected_certifications,
                'experience': experience,
                'education': education,
                'projects': projects_list,
                'peer_reviews': peer_reviews
            }
            
            # If existing employee, update
            if employee.get('employee_id'):
                employee_data['employee_id'] = employee.get('employee_id')
                success = update_employee(employee.get('employee_id'), employee_data)
                if success:
                    st.success(f"Employee {name} updated successfully!")
                    return True
                else:
                    st.error("Failed to update employee.")
                    return False
            # Otherwise add new
            else:
                employee_id = add_employee(employee_data)
                if employee_id:
                    st.balloons()  # Add visual celebration effect
                    st.success(f"✅ Employee {name} has been successfully added to the database! Employee ID: {employee_id}")
                    
                    # Add additional confirmation details
                    st.info(f"""
                    **Employee Details:**
                    - **Name:** {name}
                    - **Department:** {department}
                    - **Job Title:** {job_title}
                    - **Skills:** {', '.join(selected_skills) if selected_skills else 'None'}
                    
                    The employee has been saved to the database and can now be matched with suitable roles.
                    """)
                    return True
                else:
                    st.error("Failed to add employee.")
                    return False
    
    return False

def employee_management_page():
    st.title("Employee Management")
    
    # Tabs for list view and add/edit
    tab1, tab2 = st.tabs(["Employee List", "Add/Edit Employee"])
    
    with tab1:
        st.subheader("Employee Database")
        
        # Filter options
        st.write("Filter Options:")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            name_filter = st.text_input("Filter by Name")
        
        with col2:
            departments = sorted(list(st.session_state.departments))
            department_filter = st.selectbox(
                "Filter by Department", 
                options=["All"] + departments
            )
        
        with col3:
            skills_list = sorted(list(st.session_state.skills))
            skill_filter = st.selectbox(
                "Filter by Skill", 
                options=["All"] + skills_list
            )
        
        # Apply filters
        filters = {}
        if name_filter:
            filters['name'] = name_filter
        
        if department_filter != "All":
            filters['department'] = department_filter
        
        if skill_filter != "All":
            filters['skills'] = [skill_filter]
        
        filtered_employees = filter_employees(filters)
        
        # Display employee table
        if len(filtered_employees) > 0:
            # Select columns to display in the table
            display_cols = ['employee_id', 'name', 'department', 'job_title', 'experience', 'education']
            
            # Create a display dataframe with only the selected columns
            display_df = filtered_employees[display_cols].copy()
            
            # Add action column
            st.dataframe(display_df, use_container_width=True)
            
            # Employee selection for actions
            selected_employee_id = st.selectbox(
                "Select Employee for Actions", 
                options=filtered_employees['employee_id'].tolist(),
                format_func=lambda x: f"{filtered_employees[filtered_employees['employee_id']==x]['name'].values[0]} (ID: {x})"
            )
            
            if selected_employee_id:
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    if st.button("View Details"):
                        # Store the selected employee ID in session state for the details view
                        st.session_state.selected_employee_id = selected_employee_id
                        st.session_state.employee_action = "view"
                        # Switch to the details tab
                        st.rerun()
                
                with col2:
                    if st.button("Edit"):
                        # Store the selected employee ID in session state for editing
                        st.session_state.selected_employee_id = selected_employee_id
                        st.session_state.employee_action = "edit"
                        # Switch to the edit tab
                        st.rerun()
                
                with col3:
                    if st.button("Delete"):
                        # Confirm deletion
                        if st.checkbox("Confirm deletion"):
                            success = delete_employee(selected_employee_id)
                            if success:
                                st.success("Employee deleted successfully!")
                                st.session_state.selected_employee_id = None
                                st.rerun()
                            else:
                                st.error("Failed to delete employee.")
        else:
            st.info("No employees found. Add employees using the 'Add/Edit Employee' tab.")
    
    with tab2:
        # Check if we're editing an existing employee
        if hasattr(st.session_state, 'employee_action') and st.session_state.employee_action == "edit" and hasattr(st.session_state, 'selected_employee_id'):
            employee_id = st.session_state.selected_employee_id
            employee = get_employee_by_id(employee_id)
            
            if employee is not None:
                st.subheader(f"Edit Employee: {employee['name']}")
                if display_employee_form(employee):
                    # Reset state after successful edit
                    st.session_state.employee_action = None
                    st.session_state.selected_employee_id = None
                    st.rerun()
            else:
                st.error("Employee not found.")
        # Otherwise show the form for adding a new employee
        else:
            st.subheader("Add New Employee")
            if display_employee_form():
                # Reset form after successful add
                st.rerun()

# Run the page
employee_management_page()
