import streamlit as st
import pandas as pd
import json
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import sys
import os
import random

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import data_manager as dm
import matching_algorithm as ma
import text_processor as tp
import visualizations as viz

# Initialize session state
if 'employees' not in st.session_state or 'roles' not in st.session_state:
    dm.initialize_data()

# Set page config
st.set_page_config(
    page_title="Career Progression | Chevron Skills Assessment & Matching System",
    page_icon="📊",
    layout="wide"
)

# Define Chevron brand colors
chevron_blue = "#0050AA"
chevron_red = "#E21836"

# Add custom CSS
st.markdown("""
<style>
    [data-testid="stSidebar"] {
        background-color: #f8f9fa;
    }
    .main .block-container {
        padding-top: 2rem;
    }
    h1, h2, h3, h4, h5, h6 {
        color: #0050AA;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 10px;
    }
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: #f8f9fa;
        border-radius: 4px 4px 0 0;
        gap: 1px;
        padding-top: 10px;
        padding-bottom: 10px;
    }
    .stTabs [aria-selected="true"] {
        background-color: #0050AA !important;
        color: white !important;
    }
    .career-path-card {
        padding: 1.5rem;
        border-radius: 0.5rem;
        background: linear-gradient(135deg, rgba(0, 80, 170, 0.1), rgba(0, 80, 170, 0.05));
        border-left: 6px solid #0050AA;
        margin-bottom: 1rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .career-path-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
    }
    .skill-gap-badge {
        display: inline-block;
        padding: 3px 10px;
        border-radius: 15px;
        font-size: 0.8rem;
        margin-right: 5px;
        margin-bottom: 5px;
        background-color: rgba(226, 24, 54, 0.1);
        color: #E21836;
        border: 1px solid rgba(226, 24, 54, 0.3);
    }
    .skill-strength-badge {
        display: inline-block;
        padding: 3px 10px;
        border-radius: 15px;
        font-size: 0.8rem;
        margin-right: 5px;
        margin-bottom: 5px;
        background-color: rgba(0, 80, 170, 0.1);
        color: #0050AA;
        border: 1px solid rgba(0, 80, 170, 0.3);
    }
    .recommendation-card {
        padding: 1rem;
        border-radius: 0.5rem;
        background: white;
        border-left: 4px solid #0050AA;
        margin-bottom: 1rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }
    .success-metric {
        text-align: center;
        padding: 1rem;
        background: linear-gradient(135deg, rgba(0, 80, 170, 0.15), rgba(0, 80, 170, 0.05));
        border-radius: 0.5rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        transition: transform 0.3s ease;
    }
    .success-metric:hover {
        transform: translateY(-5px);
    }
</style>
""", unsafe_allow_html=True)

# Page title with Chevron branding
st.markdown(f"""
<div style="display: flex; align-items: center; margin-bottom: 1rem;">
    <h1 style="margin: 0; color: {chevron_blue};">Career Progression Recommendations</h1>
</div>
<p style="color: #666; font-size: 1.1rem; margin-bottom: 2rem;">
    Personalized career development paths based on skill analysis and organizational needs.
</p>
""", unsafe_allow_html=True)

# Function to generate development plans
def generate_development_plan(employee, target_role):
    # Create mock recommendations based on roles
    recommendations = [
        {
            "skill": "Python Programming",
            "action": "Technical Training",
            "description": "Complete Chevron's internal course on Python or enroll in an external certification program.",
            "timeline": "3-6 months",
            "resources": ["Chevron University", "LinkedIn Learning", "Coursera Professional Certificate"]
        },
        {
            "skill": "Leadership",
            "action": "Soft Skills Development",
            "description": "Participate in Chevron's Leadership Development Program to enhance leadership capabilities.",
            "timeline": "6-12 months",
            "resources": ["Leadership Workshop", "Executive Mentoring Program", "Communication Masterclass"]
        },
        {
            "skill": "Data Analysis",
            "action": "Project-Based Learning",
            "description": "Join cross-functional projects that require data analysis to gain practical experience.",
            "timeline": "2-4 months",
            "resources": ["Innovation Lab", "Special Projects Team", "Interdepartmental Collaboration"]
        }
    ]
    
    return recommendations

# Function to generate career path visualization
def plot_career_path(current_role, target_roles, employee_skills):
    # Create figure
    fig = go.Figure()
    
    # Set up the nodes
    nodes = [current_role] + target_roles
    
    # Calculate match scores for target roles (simplified)
    scores = [random.randint(60, 95) for _ in range(len(target_roles))]
    
    # Create node positions
    x_positions = [0] + [1 for _ in range(len(target_roles))]
    y_positions = [0] + [i * (10/(len(target_roles))) - 5 + (10/(len(target_roles)))/2 for i in range(len(target_roles))]
    
    # Add current role node
    fig.add_trace(go.Scatter(
        x=[x_positions[0]],
        y=[y_positions[0]],
        mode='markers+text',
        marker=dict(
            size=25,
            color=chevron_blue,
            symbol='circle'
        ),
        text=[current_role],
        textposition="middle right",
        name=current_role,
        hoverinfo='text',
        hovertext=f"Current Role: {current_role}"
    ))
    
    # Add target role nodes
    for i, role in enumerate(target_roles):
        fig.add_trace(go.Scatter(
            x=[x_positions[i+1]],
            y=[y_positions[i+1]],
            mode='markers+text',
            marker=dict(
                size=20,
                color=chevron_red,
                symbol='circle',
                opacity=scores[i]/100
            ),
            text=[role],
            textposition="middle right",
            name=role,
            hoverinfo='text',
            hovertext=f"Target Role: {role}<br>Match Score: {scores[i]}%"
        ))
        
        # Add connecting line
        fig.add_trace(go.Scatter(
            x=[x_positions[0], x_positions[i+1]],
            y=[y_positions[0], y_positions[i+1]],
            mode='lines',
            line=dict(
                width=2,
                color='rgba(0, 80, 170, 0.4)',
                dash='dot'
            ),
            hoverinfo='none',
            showlegend=False
        ))
    
    # Update layout
    fig.update_layout(
        showlegend=False,
        height=400,
        width=600,
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        margin=dict(l=10, r=10, t=10, b=10),
        xaxis=dict(
            showgrid=False,
            zeroline=False,
            showticklabels=False,
            range=[-0.2, 1.5]
        ),
        yaxis=dict(
            showgrid=False,
            zeroline=False,
            showticklabels=False,
            range=[-5.5, 5.5]
        )
    )
    
    return fig

# Function to plot skill growth projection
def plot_skill_growth_projection(skills, months=24):
    # Create a DataFrame for the projection
    dates = [(datetime.now() + timedelta(days=30*i)).strftime('%Y-%m') for i in range(months)]
    
    data = {}
    for skill in skills:
        # Generate growth curve with some randomness
        base_value = 100
        growth_rate = random.uniform(0.01, 0.05)  # 1-5% monthly growth
        values = [base_value]
        
        for i in range(1, months):
            # Add some volatility to the growth
            monthly_growth = growth_rate * (1 + random.uniform(-0.5, 0.5))
            new_value = values[-1] * (1 + monthly_growth)
            values.append(new_value)
        
        data[skill] = values
    
    # Create DataFrame
    df = pd.DataFrame(data, index=dates)
    
    # Normalize values for better visualization
    for col in df.columns:
        df[col] = df[col] / df[col].iloc[0] * 100
    
    # Create plot
    fig = px.line(df, 
                 labels={"value": "Demand Index", "index": "Date"},
                 title="Projected Skill Demand Growth")
    
    fig.update_layout(
        xaxis_title="Timeline",
        yaxis_title="Relative Demand (Index: 100 = Current)",
        legend_title="Skills",
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        hovermode="x unified"
    )
    
    return fig

def career_progression_page():
    # Create tabs for different aspects of career progression
    tab1, tab2, tab3, tab4 = st.tabs([
        "📊 Career Pathways", 
        "📈 Skill Gap Analysis", 
        "📝 Performance Reviews", 
        "🔮 Future Skill Projections"
    ])
    
    # Career Pathways Tab
    with tab1:
        st.markdown(f"""
        <h3 style="color: {chevron_blue};">Career Advancement Opportunities</h3>
        <p>Explore potential career paths based on your current skills and company needs.</p>
        """, unsafe_allow_html=True)
        
        # Employee selection
        if len(st.session_state.employees) > 0:
            # Convert to DataFrame if it's a list
            employees_data = st.session_state.employees
            if isinstance(employees_data, list):
                employees_data = pd.DataFrame(employees_data)
            
            # Create a selectbox for employees
            employee_options = employees_data["employee_id"].tolist() if "employee_id" in employees_data.columns else []
            selected_employee_id = st.selectbox(
                "Select employee to view career pathways:",
                options=employee_options,
                index=0 if employee_options else None
            )
            
            if selected_employee_id:
                # Get the employee data
                employee = employees_data[employees_data["employee_id"] == selected_employee_id].iloc[0]
                
                # Display employee info
                col1, col2 = st.columns([3, 2])
                
                with col1:
                    st.markdown(f"""
                    <div style="padding: 1.5rem; border-radius: 0.5rem; background: linear-gradient(135deg, rgba(0, 80, 170, 0.15), rgba(0, 80, 170, 0.05)); margin-bottom: 1rem;">
                        <h4 style="color: {chevron_blue}; margin-top: 0;">{employee['name']}</h4>
                        <p><strong>Current Position:</strong> {employee['job_title']}</p>
                        <p><strong>Department:</strong> {employee['department']}</p>
                        <p><strong>Experience:</strong> {employee['experience']} years</p>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    # Display potential career paths
                    st.markdown(f"<h4 style='color: {chevron_blue};'>Recommended Career Paths</h4>", unsafe_allow_html=True)
                    
                    # Simulated career path recommendations
                    career_paths = [
                        {
                            "title": "Technical Leadership Track",
                            "roles": ["Senior " + employee['job_title'], "Technical Lead", "Engineering Manager"],
                            "time_estimate": "3-5 years",
                            "compatibility_score": 85
                        },
                        {
                            "title": "Management Track",
                            "roles": ["Team Lead", "Department Manager", "Director"],
                            "time_estimate": "4-7 years",
                            "compatibility_score": 72
                        },
                        {
                            "title": "Specialist Track",
                            "roles": ["Subject Matter Expert", "Technical Specialist", "Technical Advisor"],
                            "time_estimate": "2-4 years",
                            "compatibility_score": 91
                        }
                    ]
                    
                    # Display career paths as cards
                    for path in career_paths:
                        st.markdown(f"""
                        <div class="career-path-card">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                                <h5 style="margin: 0; color: {chevron_blue};">{path['title']}</h5>
                                <span style="background-color: {'rgba(0, 80, 170, 0.9)' if path['compatibility_score'] >= 80 else 'rgba(226, 24, 54, 0.9)'}; 
                                     color: white; padding: 3px 8px; border-radius: 15px; font-size: 0.8rem;">
                                    {path['compatibility_score']}% Match
                                </span>
                            </div>
                            <p><strong>Progression:</strong> {" → ".join(path['roles'])}</p>
                            <p><strong>Estimated Timeline:</strong> {path['time_estimate']}</p>
                            <div style="text-align: right;">
                                <button style="background-color: {chevron_blue}; border: none; color: white; 
                                         padding: 5px 12px; border-radius: 4px; cursor: pointer; font-size: 0.85rem;">
                                    View Development Plan
                                </button>
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                
                with col2:
                    # Get skills for visualization
                    try:
                        employee_skills = json.loads(employee['skills']) if isinstance(employee['skills'], str) and employee['skills'] else []
                    except (json.JSONDecodeError, KeyError):
                        employee_skills = employee.get('skills', [])
                        if not isinstance(employee_skills, list):
                            employee_skills = []
                    if True:
                        st.markdown(f"<h4 style='color: {chevron_blue};'>Career Path Visualization</h4>", unsafe_allow_html=True)
                        
                        # Get current role and potential target roles
                        current_role = employee['job_title']
                        target_roles = [path['roles'][0] for path in career_paths]
                        
                        # Create and display visualization
                        fig = plot_career_path(current_role, target_roles, employee_skills)
                        st.plotly_chart(fig, use_container_width=True)
                        
                        # Display career success metrics
                        st.markdown(f"<h4 style='color: {chevron_blue};'>Career Success Metrics</h4>", unsafe_allow_html=True)
                        
                        metric_col1, metric_col2, metric_col3 = st.columns(3)
                        
                        with metric_col1:
                            st.markdown(f"""
                            <div class="success-metric">
                                <h3 style="margin: 0; color: {chevron_blue};">{random.randint(7, 15)}</h3>
                                <p style="margin: 0;">Critical Skills</p>
                            </div>
                            """, unsafe_allow_html=True)
                            
                        with metric_col2:
                            st.markdown(f"""
                            <div class="success-metric">
                                <h3 style="margin: 0; color: {chevron_blue};">{random.randint(3, 8)}</h3>
                                <p style="margin: 0;">Certifications</p>
                            </div>
                            """, unsafe_allow_html=True)
                            
                        with metric_col3:
                            st.markdown(f"""
                            <div class="success-metric">
                                <h3 style="margin: 0; color: {chevron_blue};">{random.randint(2, 5)}</h3>
                                <p style="margin: 0;">Promotion Paths</p>
                            </div>
                            """, unsafe_allow_html=True)
            else:
                st.info("No employees found. Please add employees in the Employee Management section.")
        else:
            st.info("No employees found. Please add employees in the Employee Management section.")
    
    # Skill Gap Analysis Tab
    with tab2:
        st.markdown(f"""
        <h3 style="color: {chevron_blue};">Skill Gap Analysis</h3>
        <p>Identify skill gaps between your current profile and target roles to create a strategic development plan.</p>
        """, unsafe_allow_html=True)
        
        # Employee and role selection
        col1, col2 = st.columns(2)
        
        with col1:
            # Employee selection
            if 'employees' in st.session_state and len(st.session_state.employees) > 0:
                employee_data = st.session_state.employees
                employee_options = employee_data["employee_id"].tolist() if isinstance(employee_data, pd.DataFrame) and "employee_id" in employee_data.columns else []
                
                if employee_options:
                    selected_employee_id = st.selectbox(
                        "Select employee:",
                        options=employee_options,
                        index=0,
                        key="skill_gap_employee"
                    )
                else:
                    selected_employee_id = None
                    st.info("No employees found. Please add employees in the Employee Management section.")
            else:
                selected_employee_id = None
                st.info("No employees found. Please add employees in the Employee Management section.")
        
        with col2:
            # Role selection
            if 'roles' in st.session_state and len(st.session_state.roles) > 0:
                role_data = st.session_state.roles
                role_options = role_data["role_id"].tolist() if isinstance(role_data, pd.DataFrame) and "role_id" in role_data.columns else []
                
                if role_options:
                    selected_role_id = st.selectbox(
                        "Select target role:",
                        options=role_options,
                        index=0,
                        key="skill_gap_role"
                    )
                else:
                    selected_role_id = None
                    st.info("No roles found. Please add roles in the Role Management section.")
            else:
                selected_role_id = None
                st.info("No roles found. Please add roles in the Role Management section.")
        
        # Display skill gap analysis if both employee and role are selected
        if selected_employee_id and selected_role_id:
            # Get the employee and role data
            employee = st.session_state.employees[st.session_state.employees["employee_id"] == selected_employee_id].iloc[0]
            role = st.session_state.roles[st.session_state.roles["role_id"] == selected_role_id].iloc[0]
            
            # Display analysis content
            st.markdown(f"<h4 style='color: {chevron_blue};'>Development Plan for {employee['name']} → {role['title']}</h4>", unsafe_allow_html=True)
            
            # Generate development plan
            development_plan = generate_development_plan(employee, role)
            
            # Display development plan
            for i, recommendation in enumerate(development_plan):
                st.markdown(f"""
                <div class="recommendation-card">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                        <h5 style="margin: 0; color: {chevron_blue};">{recommendation['skill']}</h5>
                        <span style="background-color: rgba(0, 80, 170, 0.1); color: {chevron_blue}; 
                             padding: 3px 8px; border-radius: 15px; font-size: 0.8rem;">
                            {recommendation['action']}
                        </span>
                    </div>
                    <p style="margin-bottom: 0.5rem;">{recommendation['description']}</p>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <span style="font-size: 0.85rem; color: #666;">Timeline: {recommendation['timeline']}</span>
                        </div>
                        <div>
                            <span style="font-size: 0.85rem; color: #666;">Resources: {', '.join(recommendation['resources'][:2])}</span>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
            
            # Call to action
            st.markdown(f"""
            <div style="margin-top: 1.5rem; text-align: center;">
                <button style="background-color: {chevron_blue}; border: none; color: white; 
                         padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: bold;">
                    Request Manager Approval
                </button>
            </div>
            """, unsafe_allow_html=True)
    
    # Performance Reviews Tab
    with tab3:
        st.markdown(f"""
        <h3 style="color: {chevron_blue};">Performance Review Analysis</h3>
        <p>Analyze past performance reviews to identify strengths and areas for improvement.</p>
        """, unsafe_allow_html=True)
        
        # Employee selection for performance review
        if 'employees' in st.session_state and len(st.session_state.employees) > 0:
            employee_data = st.session_state.employees
            employee_options = employee_data["employee_id"].tolist() if isinstance(employee_data, pd.DataFrame) and "employee_id" in employee_data.columns else []
            
            if employee_options:
                selected_employee_id = st.selectbox(
                    "Select employee to view performance reviews:",
                    options=employee_options,
                    index=0,
                    key="performance_employee"
                )
                
                # Display simulated performance reviews
                if selected_employee_id:
                    employee = st.session_state.employees[st.session_state.employees["employee_id"] == selected_employee_id].iloc[0]
                    
                    # Display employee info
                    st.markdown(f"""
                    <div style="padding: 1rem; border-radius: 0.5rem; background: linear-gradient(135deg, rgba(0, 80, 170, 0.1), rgba(0, 80, 170, 0.05)); margin-bottom: 1rem;">
                        <h4 style="color: {chevron_blue}; margin-top: 0;">{employee['name']}</h4>
                        <p style="margin-bottom: 0;"><strong>Position:</strong> {employee['job_title']} | <strong>Department:</strong> {employee['department']}</p>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    # Simulated performance reviews
                    reviews = [
                        {
                            "period": "2024-Q1",
                            "rating": 4.2,
                            "strengths": ["Technical expertise", "Problem solving", "Teamwork"],
                            "improvements": ["Communication", "Documentation"],
                            "highlights": "Successfully completed the XYZ project ahead of schedule"
                        },
                        {
                            "period": "2023-Q4",
                            "rating": 3.9,
                            "strengths": ["Analytical skills", "Decision making"],
                            "improvements": ["Time management", "Delegation"],
                            "highlights": "Developed innovative solution for ABC challenge"
                        },
                        {
                            "period": "2023-Q3",
                            "rating": 4.0,
                            "strengths": ["Initiative", "Adaptability"],
                            "improvements": ["Strategic planning"],
                            "highlights": "Led cross-functional team for critical system upgrade"
                        }
                    ]
                    
                    # Display overview metrics
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        avg_rating = sum(review["rating"] for review in reviews) / len(reviews)
                        st.metric(
                            label="Average Rating",
                            value=f"{avg_rating:.1f}/5.0",
                            delta="+0.2 from last year"
                        )
                    
                    with col2:
                        st.metric(
                            label="Skill Growth",
                            value="18%",
                            delta="Up from 12% last year"
                        )
                    
                    with col3:
                        st.metric(
                            label="Promotion Readiness",
                            value="Medium-High",
                            delta="Improved"
                        )
                    
                    # Display detailed reviews
                    st.markdown(f"<h4 style='color: {chevron_blue}; margin-top: 1.5rem;'>Performance Review History</h4>", unsafe_allow_html=True)
                    
                    for review in reviews:
                        color_map = {
                            "low": "#dc3545",
                            "medium": "#fd7e14",
                            "high": "#28a745"
                        }
                        
                        rating_color = color_map["high"] if review["rating"] >= 4.0 else (color_map["medium"] if review["rating"] >= 3.5 else color_map["low"])
                        
                        st.markdown(f"""
                        <div style="padding: 1.2rem; border-radius: 0.5rem; background: white; margin-bottom: 1rem; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05); border-left: 6px solid {rating_color};">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; border-bottom: 1px solid #f0f0f0; padding-bottom: 0.75rem;">
                                <h5 style="margin: 0; color: {chevron_blue};">Review Period: {review["period"]}</h5>
                                <span style="background-color: rgba(40, 167, 69, 0.1); color: {rating_color}; padding: 3px 10px; border-radius: 15px; font-weight: bold;">
                                    Rating: {review["rating"]}/5.0
                                </span>
                            </div>
                            <p><strong>Key Strengths:</strong> {", ".join(review["strengths"])}</p>
                            <p><strong>Areas for Improvement:</strong> {", ".join(review["improvements"])}</p>
                            <p><strong>Highlights:</strong> {review["highlights"]}</p>
                        </div>
                        """, unsafe_allow_html=True)
                    
                    # Development recommendations based on reviews
                    st.markdown(f"<h4 style='color: {chevron_blue}; margin-top: 1.5rem;'>Development Recommendations</h4>", unsafe_allow_html=True)
                    
                    all_improvements = [item for review in reviews for item in review["improvements"]]
                    improvement_counts = {}
                    for item in all_improvements:
                        improvement_counts[item] = improvement_counts.get(item, 0) + 1
                    
                    sorted_improvements = sorted(improvement_counts.items(), key=lambda x: x[1], reverse=True)
                    
                    for improvement, count in sorted_improvements:
                        priority = "High" if count > 1 else "Medium"
                        st.markdown(f"""
                        <div style="padding: 1rem; border-radius: 0.5rem; background: white; margin-bottom: 0.75rem; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <h5 style="margin: 0; color: {chevron_blue};">{improvement}</h5>
                                <span style="background-color: {'rgba(220, 53, 69, 0.1)' if priority == 'High' else 'rgba(255, 193, 7, 0.1)'}; 
                                     color: {'#dc3545' if priority == 'High' else '#ffc107'}; 
                                     padding: 3px 8px; border-radius: 15px; font-size: 0.8rem;">
                                    {priority} Priority
                                </span>
                            </div>
                            <p style="margin-top: 0.5rem; margin-bottom: 0;">Recommended actions:</p>
                            <ul style="margin-top: 0.25rem;">
                                <li>Attend {improvement} workshop or training</li>
                                <li>Schedule regular feedback sessions focused on {improvement.lower()}</li>
                                <li>Partner with a mentor who excels in this area</li>
                            </ul>
                        </div>
                        """, unsafe_allow_html=True)
            else:
                st.info("No employees found. Please add employees in the Employee Management section.")
        else:
            st.info("No employees found. Please add employees in the Employee Management section.")
    
    # Future Skill Projections Tab
    with tab4:
        st.markdown(f"""
        <h3 style="color: {chevron_blue};">Future Skill Projections</h3>
        <p>Analyze future skill demands and prepare for emerging industry trends.</p>
        """, unsafe_allow_html=True)
        
        col1, col2 = st.columns([3, 2])
        
        with col1:
            # Insights on future skill demands
            st.markdown(f"""
            <div style="padding: 1.5rem; border-radius: 0.5rem; background: linear-gradient(135deg, rgba(0, 80, 170, 0.1), rgba(0, 80, 170, 0.05)); 
                 margin-bottom: 1.5rem; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.08);">
                <h4 style="color: {chevron_blue}; margin-top: 0;">Industry Trends & Future Skill Demands</h4>
                <p>The energy sector is evolving rapidly with emerging technologies and sustainability initiatives. Based on industry analysis, 
                   the following skills are projected to be in high demand over the next 5 years:</p>
            </div>
            """, unsafe_allow_html=True)
            
            # Projected skill growth
            skills = ["Data Science", "Sustainability", "Cloud Computing", "Automation", "AI Applications"]
            fig = plot_skill_growth_projection(skills)
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Skills in high demand
            st.markdown(f"<h4 style='color: {chevron_blue};'>Skills in High Demand</h4>", unsafe_allow_html=True)
            
            high_demand_skills = [
                {"skill": "Data Science", "growth": "+87%"},
                {"skill": "Automation", "growth": "+65%"},
                {"skill": "Sustainability", "growth": "+58%"},
                {"skill": "Digital Twin", "growth": "+52%"},
                {"skill": "AI Applications", "growth": "+45%"},
                {"skill": "Cloud Computing", "growth": "+42%"},
                {"skill": "Cybersecurity", "growth": "+38%"},
                {"skill": "Remote Operations", "growth": "+35%"}
            ]
            
            st.markdown("""
            <div style="background: white; border-radius: 0.5rem; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="border-bottom: 1px solid #e0e0e0;">
                            <th style="padding: 0.75rem; text-align: left; color: #0050AA;">Skill</th>
                            <th style="padding: 0.75rem; text-align: right; color: #0050AA;">Growth</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr style="border-bottom: 1px solid #f0f0f0;">
                            <td style="padding: 0.75rem;">Data Science</td>
                            <td style="padding: 0.75rem; text-align: right; color: #28a745; font-weight: bold;">+87%</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #f0f0f0;">
                            <td style="padding: 0.75rem;">Automation</td>
                            <td style="padding: 0.75rem; text-align: right; color: #28a745; font-weight: bold;">+65%</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #f0f0f0;">
                            <td style="padding: 0.75rem;">Sustainability</td>
                            <td style="padding: 0.75rem; text-align: right; color: #28a745; font-weight: bold;">+58%</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #f0f0f0;">
                            <td style="padding: 0.75rem;">Digital Twin</td>
                            <td style="padding: 0.75rem; text-align: right; color: #28a745; font-weight: bold;">+52%</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #f0f0f0;">
                            <td style="padding: 0.75rem;">AI Applications</td>
                            <td style="padding: 0.75rem; text-align: right; color: #28a745; font-weight: bold;">+45%</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            """, unsafe_allow_html=True)
            
            # Strategic recommendations
            st.markdown(f"<h4 style='color: {chevron_blue}; margin-top: 1.5rem;'>Strategic Recommendations</h4>", unsafe_allow_html=True)
            
            recommendations = [
                "Invest in data science and analytics skills",
                "Develop sustainability expertise",
                "Build cloud computing proficiency",
                "Gain experience with digital twin technology",
                "Enhance remote collaboration capabilities"
            ]
            
            recommendation_html = "<div style='padding: 1rem; border-radius: 0.5rem; background: linear-gradient(135deg, rgba(0, 80, 170, 0.1), rgba(0, 80, 170, 0.05)); margin-bottom: 1rem; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);'><ul style='margin: 0; padding-left: 1.5rem;'>"
            
            for rec in recommendations:
                recommendation_html += f"<li style='margin-bottom: 0.5rem;'>{rec}</li>"
                
            recommendation_html += "</ul></div>"
            
            st.markdown(recommendation_html, unsafe_allow_html=True)
            
            # Call to action
            st.markdown(f"""
            <div style="padding: 1rem; border-radius: 0.5rem; background: linear-gradient(135deg, rgba(226, 24, 54, 0.15), rgba(226, 24, 54, 0.05)); 
                 margin-top: 1.5rem; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05); text-align: center;">
                <h5 style="margin: 0 0 0.5rem 0; color: {chevron_red};">Ready to Future-Proof Your Career?</h5>
                <p style="margin-bottom: 1rem;">Schedule a career development consultation with an HR advisor to create your personalized skill development roadmap.</p>
                <button style="background-color: {chevron_red}; border: none; color: white; padding: 8px 16px; 
                     border-radius: 4px; cursor: pointer; font-weight: bold;">
                    Schedule Consultation
                </button>
            </div>
            """, unsafe_allow_html=True)

# Run the career progression page
career_progression_page()