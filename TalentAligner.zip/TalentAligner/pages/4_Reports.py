import streamlit as st
import pandas as pd
import numpy as np
import sys
import os
import io
import datetime

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from visualizations import (
    plot_skill_distribution,
    plot_department_distribution,
    plot_hiring_needs_forecast,
    plot_match_history_trend,
    plot_match_score_radar,
    plot_skill_gap_analysis
)
import data_manager as dm
from data_manager import export_data

# Initialize session state
if 'employees' not in st.session_state or 'roles' not in st.session_state:
    dm.initialize_data()

def reports_page():
    st.title("Reports and Analytics")
    
    # Tabs for different report types
    tab1, tab2, tab3, tab4 = st.tabs([
        "Workforce Analytics", 
        "Match Reports", 
        "Skill Gap Analysis",
        "Export Data"
    ])
    
    with tab1:
        st.subheader("Workforce Analytics")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Department distribution chart
            if len(st.session_state.employees) > 0:
                dept_fig = plot_department_distribution()
                st.plotly_chart(dept_fig, use_container_width=True)
            else:
                st.info("No employee data available for department distribution.")
        
        with col2:
            # Skill distribution chart
            if len(st.session_state.employees) > 0:
                skill_fig = plot_skill_distribution()
                st.plotly_chart(skill_fig, use_container_width=True)
            else:
                st.info("No employee data available for skill distribution.")
        
        # Projected hiring needs
        st.subheader("Projected Hiring Needs")
        if len(st.session_state.roles) > 0:
            hiring_fig = plot_hiring_needs_forecast()
            st.plotly_chart(hiring_fig, use_container_width=True)
        else:
            st.info("No role data available for hiring needs projection.")
    
    with tab2:
        st.subheader("Match Reports")
        
        # Match score trend
        if len(st.session_state.matches) > 0:
            match_trend_fig = plot_match_history_trend()
            st.plotly_chart(match_trend_fig, use_container_width=True)
            
            # Display top matches
            st.subheader("Top Matches Overview")
            
            # Get matches sorted by score
            top_matches = st.session_state.matches.sort_values('match_score', ascending=False).head(10)
            
            # Add employee and role names
            top_matches['employee_name'] = top_matches['employee_id'].apply(
                lambda x: st.session_state.employees[st.session_state.employees['employee_id']==x]['name'].values[0] 
                if len(st.session_state.employees[st.session_state.employees['employee_id']==x]) > 0 else 'Unknown'
            )
            
            top_matches['role_title'] = top_matches['role_id'].apply(
                lambda x: st.session_state.roles[st.session_state.roles['role_id']==x]['title'].values[0] 
                if len(st.session_state.roles[st.session_state.roles['role_id']==x]) > 0 else 'Unknown'
            )
            
            # Format match score as percentage
            top_matches['match_score'] = top_matches['match_score'].apply(lambda x: f"{x*100:.1f}%")
            
            # Display the table
            st.dataframe(
                top_matches[['employee_name', 'role_title', 'match_score', 'match_date']],
                use_container_width=True
            )
        else:
            st.info("No match data available for match reports.")
        
        # Detailed match report (if available from skill matching page)
        if hasattr(st.session_state, 'detailed_match'):
            st.subheader("Detailed Match Report")
            
            detailed_match = st.session_state.detailed_match
            employee = detailed_match['employee']
            role = detailed_match['role']
            scores = detailed_match['scores']
            
            st.write(f"### Match: {employee['name']} → {role['title']}")
            
            col1, col2 = st.columns([1, 2])
            
            with col1:
                # Display overall score
                st.metric(
                    label="Overall Match Score", 
                    value=f"{scores['overall'] * 100:.1f}%"
                )
                
                # Display component scores
                st.write("Component Scores:")
                st.info(f"💻 Skills: {scores['skill_match'] * 100:.1f}%")
                st.info(f"⏳ Experience: {scores['experience_match'] * 100:.1f}%")
                st.info(f"🏆 Certifications: {scores['certification_match'] * 100:.1f}%")
                st.info(f"🎓 Education: {scores['education_match'] * 100:.1f}%")
                st.info(f"🤝 Soft Skills: {scores['soft_skills'] * 100:.1f}%")
            
            with col2:
                # Radar chart for match components
                radar_fig = plot_match_score_radar(scores)
                st.plotly_chart(radar_fig, use_container_width=True)
            
            # Show skill gaps
            st.subheader("Skill Gap Analysis")
            skill_gap_fig = plot_skill_gap_analysis({
                'skill_gaps': scores['details']['skill_gaps']
            })
            st.plotly_chart(skill_gap_fig, use_container_width=True)
            
            # Recommendations based on match score
            st.subheader("Recommendations")
            
            if scores['overall'] >= 0.85:
                st.success("✅ This is an excellent match! The employee is highly suitable for this role.")
                st.write("Recommendations:")
                st.write("- Proceed with role assignment or interview process")
                st.write("- Highlight the employee's strong alignment with this role")
            elif scores['overall'] >= 0.70:
                st.success("✅ This is a good match. The employee is suitable for this role with some skill development.")
                st.write("Recommendations:")
                st.write("- Consider for the role with targeted training")
                st.write("- Focus training on the identified skill gaps")
                st.write("- Provide mentoring in areas where experience falls short")
            elif scores['overall'] >= 0.50:
                st.warning("⚠️ This is a moderate match. The employee may need significant development to succeed in this role.")
                st.write("Recommendations:")
                st.write("- Consider if investment in extensive training is justified")
                st.write("- Look for alternative roles with better skill alignment")
                st.write("- Create a detailed development plan to address skill gaps")
            else:
                st.error("❌ This is a poor match. The employee is not well-suited for this role.")
                st.write("Recommendations:")
                st.write("- Consider alternative roles that better match the employee's skills")
                st.write("- If this role is a career goal, develop a long-term training plan")
                st.write("- Look for better-matching candidates for this role")
            
            # Option to download the report
            if st.button("Download Report"):
                report_buffer = io.StringIO()
                
                # Write report content
                report_buffer.write(f"# Match Report: {employee['name']} → {role['title']}\n\n")
                report_buffer.write(f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                
                report_buffer.write("## Match Scores\n\n")
                report_buffer.write(f"Overall Match Score: {scores['overall'] * 100:.1f}%\n\n")
                report_buffer.write("Component Scores:\n")
                report_buffer.write(f"- Skills: {scores['skill_match'] * 100:.1f}%\n")
                report_buffer.write(f"- Experience: {scores['experience_match'] * 100:.1f}%\n")
                report_buffer.write(f"- Certifications: {scores['certification_match'] * 100:.1f}%\n")
                report_buffer.write(f"- Education: {scores['education_match'] * 100:.1f}%\n")
                report_buffer.write(f"- Soft Skills: {scores['soft_skills'] * 100:.1f}%\n\n")
                
                report_buffer.write("## Skill Gap Analysis\n\n")
                report_buffer.write("Missing Required Skills:\n")
                for skill in scores['details']['skill_gaps']['missing_required']:
                    report_buffer.write(f"- {skill}\n")
                report_buffer.write("\nMissing Preferred Skills:\n")
                for skill in scores['details']['skill_gaps']['missing_preferred']:
                    report_buffer.write(f"- {skill}\n")
                
                report_buffer.write("\n## Recommendations\n\n")
                if scores['overall'] >= 0.85:
                    report_buffer.write("This is an excellent match! The employee is highly suitable for this role.\n\n")
                    report_buffer.write("Recommendations:\n")
                    report_buffer.write("- Proceed with role assignment or interview process\n")
                    report_buffer.write("- Highlight the employee's strong alignment with this role\n")
                elif scores['overall'] >= 0.70:
                    report_buffer.write("This is a good match. The employee is suitable for this role with some skill development.\n\n")
                    report_buffer.write("Recommendations:\n")
                    report_buffer.write("- Consider for the role with targeted training\n")
                    report_buffer.write("- Focus training on the identified skill gaps\n")
                    report_buffer.write("- Provide mentoring in areas where experience falls short\n")
                elif scores['overall'] >= 0.50:
                    report_buffer.write("This is a moderate match. The employee may need significant development to succeed in this role.\n\n")
                    report_buffer.write("Recommendations:\n")
                    report_buffer.write("- Consider if investment in extensive training is justified\n")
                    report_buffer.write("- Look for alternative roles with better skill alignment\n")
                    report_buffer.write("- Create a detailed development plan to address skill gaps\n")
                else:
                    report_buffer.write("This is a poor match. The employee is not well-suited for this role.\n\n")
                    report_buffer.write("Recommendations:\n")
                    report_buffer.write("- Consider alternative roles that better match the employee's skills\n")
                    report_buffer.write("- If this role is a career goal, develop a long-term training plan\n")
                    report_buffer.write("- Look for better-matching candidates for this role\n")
                
                # Generate download link
                report_str = report_buffer.getvalue()
                st.download_button(
                    label="Download Report as Text",
                    data=report_str,
                    file_name=f"match_report_{employee['name']}_{role['title']}.txt",
                    mime="text/plain"
                )
    
    with tab3:
        st.subheader("Skill Gap Analysis")
        
        # Department selection for skill gap analysis
        departments = ["All"] + sorted(list(st.session_state.departments))
        selected_dept = st.selectbox(
            "Select Department", 
            options=departments
        )
        
        # Calculate skill gaps for the selected department
        if len(st.session_state.employees) > 0 and len(st.session_state.roles) > 0:
            # Filter employees by department if needed
            if selected_dept != "All":
                filtered_employees = st.session_state.employees[st.session_state.employees['department'] == selected_dept]
            else:
                filtered_employees = st.session_state.employees
            
            # Filter roles by department if needed
            if selected_dept != "All":
                filtered_roles = st.session_state.roles[st.session_state.roles['department'] == selected_dept]
            else:
                filtered_roles = st.session_state.roles
            
            # Collect all skills required by roles
            required_skills = set()
            for _, role in filtered_roles.iterrows():
                skills = role.get('required_skills', [])
                if isinstance(skills, list):
                    required_skills.update(skills)
            
            # Collect all skills possessed by employees
            employee_skills = set()
            for _, employee in filtered_employees.iterrows():
                skills = employee.get('skills', [])
                if isinstance(skills, list):
                    employee_skills.update(skills)
            
            # Calculate skill gaps
            skill_gaps = required_skills - employee_skills
            
            # Calculate skill surpluses (skills employees have that aren't required)
            skill_surpluses = employee_skills - required_skills
            
            # Display skill gaps
            st.subheader(f"Skill Gaps in {selected_dept if selected_dept != 'All' else 'All Departments'}")
            
            if skill_gaps:
                # Create DataFrame for skill gaps
                skill_gap_data = []
                
                for skill in skill_gaps:
                    # Count how many roles require this skill
                    roles_requiring = 0
                    for _, role in filtered_roles.iterrows():
                        req_skills = role.get('required_skills', [])
                        if isinstance(req_skills, list) and skill in req_skills:
                            roles_requiring += 1
                    
                    skill_gap_data.append({
                        'Skill': skill,
                        'Roles Requiring': roles_requiring,
                        'Demand': 'High' if roles_requiring > 2 else ('Medium' if roles_requiring > 1 else 'Low')
                    })
                
                skill_gap_df = pd.DataFrame(skill_gap_data)
                skill_gap_df = skill_gap_df.sort_values('Roles Requiring', ascending=False)
                
                st.dataframe(skill_gap_df, use_container_width=True)
                
                # Recommendations for skill gaps
                st.subheader("Recommendations")
                st.write("Based on the identified skill gaps, consider the following actions:")
                
                high_demand_skills = skill_gap_df[skill_gap_df['Demand'] == 'High']['Skill'].tolist()
                if high_demand_skills:
                    st.write("### High Priority")
                    st.write("These skills are required by multiple roles and should be addressed first:")
                    for skill in high_demand_skills:
                        st.write(f"- {skill}: Training programs, hiring, or external contractors")
                
                medium_demand_skills = skill_gap_df[skill_gap_df['Demand'] == 'Medium']['Skill'].tolist()
                if medium_demand_skills:
                    st.write("### Medium Priority")
                    st.write("These skills are required by some roles:")
                    for skill in medium_demand_skills:
                        st.write(f"- {skill}: Consider targeted training or hiring")
                
                low_demand_skills = skill_gap_df[skill_gap_df['Demand'] == 'Low']['Skill'].tolist()
                if low_demand_skills:
                    st.write("### Low Priority")
                    st.write("These skills are required by few roles:")
                    for skill in low_demand_skills:
                        st.write(f"- {skill}: Monitor need, consider training if demand increases")
            else:
                st.success("No skill gaps identified! All required skills are covered by the current workforce.")
            
            # Display skill surpluses
            st.subheader("Skill Surpluses")
            
            if skill_surpluses:
                st.write("These skills are possessed by employees but not currently required by any roles:")
                
                # Create columns for displaying skills
                cols = st.columns(3)
                
                for i, skill in enumerate(sorted(skill_surpluses)):
                    cols[i % 3].write(f"- {skill}")
                
                st.write("**Recommendation**: Consider how these surplus skills could be leveraged for new initiatives or roles.")
            else:
                st.info("No skill surpluses identified. All employee skills are being utilized.")
        else:
            st.info("Insufficient data for skill gap analysis. Please add employees and roles first.")
    
    with tab4:
        st.subheader("Export Data")
        
        # Select data to export
        data_type = st.selectbox(
            "Select Data to Export",
            options=["Employees", "Roles", "Matches"]
        )
        
        # Select export format
        export_format = st.selectbox(
            "Select Export Format",
            options=["CSV", "JSON"]
        )
        
        # Map selections to internal values
        data_type_map = {
            "Employees": "employees",
            "Roles": "roles",
            "Matches": "matches"
        }
        
        format_map = {
            "CSV": "csv",
            "JSON": "json"
        }
        
        # Export button
        if st.button("Export Data"):
            data = export_data(
                data_type_map[data_type],
                file_format=format_map[export_format]
            )
            
            if data is not None:
                st.download_button(
                    label=f"Download {data_type} as {export_format}",
                    data=data,
                    file_name=f"{data_type_map[data_type]}.{format_map[export_format]}",
                    mime=f"text/{format_map[export_format]}"
                )
            else:
                st.error(f"Failed to export {data_type}.")

# Run the page
reports_page()
