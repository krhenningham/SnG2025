import streamlit as st
import pandas as pd
from data_manager import (
    add_role, update_role, delete_role, 
    filter_roles, get_role_by_id
)

def display_role_form(role=None):
    """Display form for adding or editing a role"""
    # Initialize empty dictionary if no role provided
    if role is None:
        role = {
            'role_id': '',
            'title': '',
            'department': '',
            'description': '',
            'required_skills': [],
            'preferred_skills': [],
            'required_certifications': [],
            'required_experience': 0,
            'required_education': '',
            'responsibilities': []
        }
    
    # Get departments list from session state
    departments = sorted(list(st.session_state.departments))
    
    # Get skills list from session state
    skills_list = sorted(list(st.session_state.skills))
    
    # Get certifications list from session state
    certifications_list = sorted(list(st.session_state.certifications))
    
    # Create form
    with st.form("role_form"):
        st.subheader("Role Information")
        
        # Basic Information
        col1, col2 = st.columns(2)
        
        with col1:
            title = st.text_input("Role Title", value=role.get('title', ''))
            department = st.selectbox(
                "Department", 
                options=departments,
                index=departments.index(role.get('department')) if role.get('department') in departments else 0
            )
        
        with col2:
            required_experience = st.number_input(
                "Required Experience (years)", 
                min_value=0.0, 
                max_value=20.0, 
                value=float(role.get('required_experience', 0)),
                step=0.5
            )
            required_education = st.selectbox(
                "Required Education", 
                options=["None", "High School", "Associate's Degree", "Bachelor's Degree", "Master's Degree", "PhD"],
                index=["None", "High School", "Associate's Degree", "Bachelor's Degree", "Master's Degree", "PhD"].index(role.get('required_education')) if role.get('required_education') in ["None", "High School", "Associate's Degree", "Bachelor's Degree", "Master's Degree", "PhD"] else 0
            )
        
        # Description
        description = st.text_area("Role Description", value=role.get('description', ''))
        
        # Skills and Certifications
        st.subheader("Skills and Qualifications")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Required Skills with multiselect and option to add new
            required_skills = st.multiselect(
                "Required Skills", 
                options=skills_list, 
                default=role.get('required_skills', []) if isinstance(role.get('required_skills'), list) else []
            )
            
            new_req_skill = st.text_input("Add New Required Skill (Type and submit form)")
            
            # Preferred Skills
            preferred_skills = st.multiselect(
                "Preferred Skills", 
                options=skills_list, 
                default=role.get('preferred_skills', []) if isinstance(role.get('preferred_skills'), list) else []
            )
            
            new_pref_skill = st.text_input("Add New Preferred Skill (Type and submit form)")
        
        with col2:
            # Required Certifications with multiselect and option to add new
            required_certifications = st.multiselect(
                "Required Certifications", 
                options=certifications_list, 
                default=role.get('required_certifications', []) if isinstance(role.get('required_certifications'), list) else []
            )
            
            new_certification = st.text_input("Add New Required Certification (Type and submit form)")
        
        # Responsibilities
        st.subheader("Responsibilities")
        responsibilities = st.text_area(
            "Responsibilities (comma separated)", 
            value=', '.join(role.get('responsibilities', [])) if isinstance(role.get('responsibilities'), list) else role.get('responsibilities', '')
        )
        
        # Submit button
        submit_button = st.form_submit_button("Save Role")
        
        if submit_button:
            # Parse responsibilities into list
            responsibilities_list = [r.strip() for r in responsibilities.split(',') if r.strip()]
            
            # Handle new required skill if entered
            if new_req_skill and new_req_skill not in skills_list:
                st.session_state.skills.add(new_req_skill)
                required_skills.append(new_req_skill)
            
            # Handle new preferred skill if entered
            if new_pref_skill and new_pref_skill not in skills_list:
                st.session_state.skills.add(new_pref_skill)
                preferred_skills.append(new_pref_skill)
                
            # Handle new certification if entered
            if new_certification and new_certification not in certifications_list:
                st.session_state.certifications.add(new_certification)
                required_certifications.append(new_certification)
            
            # Create role data dictionary
            role_data = {
                'title': title,
                'department': department,
                'description': description,
                'required_skills': required_skills,
                'preferred_skills': preferred_skills,
                'required_certifications': required_certifications,
                'required_experience': required_experience,
                'required_education': required_education,
                'responsibilities': responsibilities_list
            }
            
            # If existing role, update
            if role.get('role_id'):
                role_data['role_id'] = role.get('role_id')
                success = update_role(role.get('role_id'), role_data)
                if success:
                    st.success(f"Role {title} updated successfully!")
                    return True
                else:
                    st.error("Failed to update role.")
                    return False
            # Otherwise add new
            else:
                role_id = add_role(role_data)
                if role_id:
                    st.balloons()  # Add visual celebration effect
                    st.success(f"✅ Role '{title}' has been successfully added to the database! Role ID: {role_id}")
                    
                    # Add additional confirmation details
                    st.info(f"""
                    **Role Details:**
                    - **Title:** {title}
                    - **Department:** {department}
                    - **Required Experience:** {required_experience} years
                    - **Required Skills:** {', '.join(required_skills) if required_skills else 'None'}
                    
                    The role has been saved to the database and can now be matched with suitable employees.
                    """)
                    return True
                else:
                    st.error("Failed to add role.")
                    return False
    
    return False

def role_management_page():
    st.title("Role Management")
    
    # Tabs for list view and add/edit
    tab1, tab2 = st.tabs(["Role List", "Add/Edit Role"])
    
    with tab1:
        st.subheader("Role Database")
        
        # Filter options
        st.write("Filter Options:")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            title_filter = st.text_input("Filter by Title")
        
        with col2:
            departments = sorted(list(st.session_state.departments))
            department_filter = st.selectbox(
                "Filter by Department", 
                options=["All"] + departments
            )
        
        with col3:
            skills_list = sorted(list(st.session_state.skills))
            skill_filter = st.selectbox(
                "Filter by Required Skill", 
                options=["All"] + skills_list
            )
        
        # Apply filters
        filters = {}
        if title_filter:
            filters['title'] = title_filter
        
        if department_filter != "All":
            filters['department'] = department_filter
        
        if skill_filter != "All":
            filters['required_skills'] = [skill_filter]
        
        filtered_roles = filter_roles(filters)
        
        # Display role table
        if len(filtered_roles) > 0:
            # Select columns to display in the table
            display_cols = ['role_id', 'title', 'department', 'required_experience', 'required_education']
            
            # Create a display dataframe with only the selected columns
            display_df = filtered_roles[display_cols].copy()
            
            # Add action column
            st.dataframe(display_df, use_container_width=True)
            
            # Role selection for actions
            selected_role_id = st.selectbox(
                "Select Role for Actions", 
                options=filtered_roles['role_id'].tolist(),
                format_func=lambda x: f"{filtered_roles[filtered_roles['role_id']==x]['title'].values[0]} (ID: {x})"
            )
            
            if selected_role_id:
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    if st.button("View Details"):
                        # Store the selected role ID in session state for the details view
                        st.session_state.selected_role_id = selected_role_id
                        st.session_state.role_action = "view"
                        # Switch to the details tab
                        st.rerun()
                
                with col2:
                    if st.button("Edit"):
                        # Store the selected role ID in session state for editing
                        st.session_state.selected_role_id = selected_role_id
                        st.session_state.role_action = "edit"
                        # Switch to the edit tab
                        st.rerun()
                
                with col3:
                    if st.button("Delete"):
                        # Confirm deletion
                        if st.checkbox("Confirm deletion"):
                            success = delete_role(selected_role_id)
                            if success:
                                st.success("Role deleted successfully!")
                                st.session_state.selected_role_id = None
                                st.rerun()
                            else:
                                st.error("Failed to delete role.")
        else:
            st.info("No roles found. Add roles using the 'Add/Edit Role' tab.")
    
    with tab2:
        # Check if we're editing an existing role
        if hasattr(st.session_state, 'role_action') and st.session_state.role_action == "edit" and hasattr(st.session_state, 'selected_role_id'):
            role_id = st.session_state.selected_role_id
            role = get_role_by_id(role_id)
            
            if role is not None:
                st.subheader(f"Edit Role: {role['title']}")
                if display_role_form(role):
                    # Reset state after successful edit
                    st.session_state.role_action = None
                    st.session_state.selected_role_id = None
                    st.rerun()
            else:
                st.error("Role not found.")
        # Otherwise show the form for adding a new role
        else:
            st.subheader("Add New Role")
            if display_role_form():
                # Reset form after successful add
                st.rerun()

# Run the page
role_management_page()
