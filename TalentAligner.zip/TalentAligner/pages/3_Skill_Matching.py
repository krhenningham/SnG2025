import streamlit as st
import pandas as pd
import numpy as np
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from matching_algorithm import (
    calculate_match_score, 
    match_employees_to_roles
)
from visualizations import (
    plot_match_score_radar,
    plot_employee_role_match_heatmap,
    plot_skill_gap_analysis
)
import data_manager as dm
from data_manager import (
    add_match,
    get_employee_by_id,
    get_role_by_id
)

# Initialize session state
if 'employees' not in st.session_state or 'roles' not in st.session_state:
    dm.initialize_data()

def skill_matching_page():
    st.title("Skill Matching")
    
    # Tabs for different matching views
    tab1, tab2, tab3, tab4 = st.tabs(["Individual Matching", "Batch Matching", "Auto Matching", "Match History"])
    
    with tab1:
        st.subheader("Match an Employee to a Role")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Employee selection
            if len(st.session_state.employees) > 0:
                employee_options = st.session_state.employees['employee_id'].tolist()
                selected_employee_id = st.selectbox(
                    "Select Employee", 
                    options=employee_options,
                    format_func=lambda x: f"{st.session_state.employees[st.session_state.employees['employee_id']==x]['name'].values[0]} (ID: {x})"
                )
            else:
                st.error("No employees in the database. Please add employees first.")
                selected_employee_id = None
        
        with col2:
            # Role selection
            if len(st.session_state.roles) > 0:
                role_options = st.session_state.roles['role_id'].tolist()
                selected_role_id = st.selectbox(
                    "Select Role", 
                    options=role_options,
                    format_func=lambda x: f"{st.session_state.roles[st.session_state.roles['role_id']==x]['title'].values[0]} (ID: {x})"
                )
            else:
                st.error("No roles in the database. Please add roles first.")
                selected_role_id = None
        
        # Calculate match if both selections are made
        if selected_employee_id and selected_role_id:
            employee = get_employee_by_id(selected_employee_id)
            role = get_role_by_id(selected_role_id)
            
            if employee is not None and role is not None:
                # Calculate match score
                match_scores = calculate_match_score(employee, role)
                
                # Display match results
                st.subheader("Match Results")
                
                col1, col2 = st.columns([1, 2])
                
                with col1:
                    # Display overall score
                    st.metric(
                        label="Overall Match Score", 
                        value=f"{match_scores['overall'] * 100:.1f}%"
                    )
                    
                    # Display component scores
                    st.write("Component Scores:")
                    st.info(f"💻 Skills: {match_scores['skill_match'] * 100:.1f}%")
                    st.info(f"⏳ Experience: {match_scores['experience_match'] * 100:.1f}%")
                    st.info(f"🏆 Certifications: {match_scores['certification_match'] * 100:.1f}%")
                    st.info(f"🎓 Education: {match_scores['education_match'] * 100:.1f}%")
                    st.info(f"🤝 Soft Skills: {match_scores['soft_skills'] * 100:.1f}%")
                
                with col2:
                    # Radar chart for match components
                    radar_fig = plot_match_score_radar(match_scores)
                    st.plotly_chart(radar_fig, use_container_width=True)
                
                # Show skill gaps
                st.subheader("Skill Gap Analysis")
                skill_gap_fig = plot_skill_gap_analysis({
                    'skill_gaps': match_scores['details']['skill_gaps']
                })
                st.plotly_chart(skill_gap_fig, use_container_width=True)
                
                # Buttons for actions
                col1, col2 = st.columns(2)
                
                with col1:
                    if st.button("Save Match Results"):
                        # Create match record
                        match_data = {
                            'employee_id': selected_employee_id,
                            'role_id': selected_role_id,
                            'match_score': match_scores['overall'],
                            'skill_match_score': match_scores['skill_match'],
                            'experience_match_score': match_scores['experience_match'],
                            'certification_match_score': match_scores['certification_match'],
                            'education_match_score': match_scores['education_match'],
                            'soft_skills_score': match_scores['soft_skills'],
                            'notes': f"Match between {employee['name']} and {role['title']}"
                        }
                        
                        match_id = add_match(match_data)
                        if match_id:
                            st.success("Match results saved successfully!")
                        else:
                            st.error("Failed to save match results.")
                
                with col2:
                    # Option to generate a detailed report
                    if st.button("Generate Detailed Report"):
                        st.session_state.detailed_match = {
                            'employee': employee,
                            'role': role,
                            'scores': match_scores
                        }
                        st.info("Detailed report generated. View in the Reports tab.")
    
    with tab2:
        st.subheader("Batch Matching")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Filter employees for batch matching
            st.write("Filter Employees:")
            departments = ["All"] + sorted(list(st.session_state.departments))
            batch_dept_filter = st.selectbox(
                "Department", 
                options=departments,
                key="batch_employee_dept"
            )
            
            # Get filtered employees
            if batch_dept_filter != "All":
                filtered_employees = st.session_state.employees[st.session_state.employees['department'] == batch_dept_filter]
            else:
                filtered_employees = st.session_state.employees
            
            if len(filtered_employees) > 0:
                st.write(f"{len(filtered_employees)} employees selected")
            else:
                st.warning("No employees match the selected filters")
        
        with col2:
            # Filter roles for batch matching
            st.write("Filter Roles:")
            role_departments = ["All"] + sorted(list(st.session_state.departments))
            batch_role_dept_filter = st.selectbox(
                "Department", 
                options=role_departments,
                key="batch_role_dept"
            )
            
            # Get filtered roles
            if batch_role_dept_filter != "All":
                filtered_roles = st.session_state.roles[st.session_state.roles['department'] == batch_role_dept_filter]
            else:
                filtered_roles = st.session_state.roles
            
            if len(filtered_roles) > 0:
                st.write(f"{len(filtered_roles)} roles selected")
            else:
                st.warning("No roles match the selected filters")
        
        # Run batch matching if both selections have results
        if len(filtered_employees) > 0 and len(filtered_roles) > 0:
            if st.button("Run Batch Matching"):
                with st.spinner("Running batch matching..."):
                    # Run the matching algorithm
                    match_results = match_employees_to_roles(
                        employees=filtered_employees,
                        roles=filtered_roles,
                        top_n=5
                    )
                    
                    # Store results in session state for display
                    st.session_state.batch_match_results = match_results
                    
                    st.success("Batch matching completed!")
        
        # Display batch matching results if available
        if hasattr(st.session_state, 'batch_match_results'):
            st.subheader("Batch Matching Results")
            
            # Display heatmap of match scores
            heatmap_fig = plot_employee_role_match_heatmap(st.session_state.batch_match_results)
            st.plotly_chart(heatmap_fig, use_container_width=True)
            
            # Display top matches for each role
            st.subheader("Top Matches by Role")
            
            # Create tabs for each role
            role_tabs = st.tabs([f"{st.session_state.roles[st.session_state.roles['role_id']==role_id]['title'].values[0]}" 
                                 for role_id in st.session_state.batch_match_results['role_to_employee'].keys()])
            
            for i, role_id in enumerate(st.session_state.batch_match_results['role_to_employee'].keys()):
                with role_tabs[i]:
                    role_matches = st.session_state.batch_match_results['role_to_employee'][role_id]
                    
                    # Convert to DataFrame for display
                    role_matches_df = pd.DataFrame(role_matches)
                    
                    # Select columns for display
                    display_cols = ['employee_name', 'overall_score', 'skill_match', 
                                   'experience_match', 'certification_match', 'education_match']
                    
                    if len(role_matches_df) > 0:
                        # Format scores as percentages
                        for col in display_cols[1:]:
                            role_matches_df[col] = role_matches_df[col].apply(lambda x: f"{x*100:.1f}%")
                        
                        # Rename columns for display
                        role_matches_df.columns = [col.replace('_', ' ').title() for col in role_matches_df.columns]
                        
                        # Display the table
                        st.dataframe(role_matches_df[['Employee Name', 'Overall Score', 'Skill Match', 
                                                     'Experience Match', 'Certification Match', 'Education Match']], 
                                     use_container_width=True)
                        
                        # Option to save matches
                        if st.button(f"Save All Matches for {st.session_state.roles[st.session_state.roles['role_id']==role_id]['title'].values[0]}", key=f"save_role_{role_id}"):
                            saved_count = 0
                            for match in role_matches:
                                match_data = {
                                    'employee_id': match['employee_id'],
                                    'role_id': role_id,
                                    'match_score': match['overall_score'],
                                    'skill_match_score': match['skill_match'],
                                    'experience_match_score': match['experience_match'],
                                    'certification_match_score': match['certification_match'],
                                    'education_match_score': match['education_match'],
                                    'soft_skills_score': match['soft_skills'],
                                    'notes': f"Batch match for {match['employee_name']} and {match['role_title']}"
                                }
                                
                                match_id = add_match(match_data)
                                if match_id:
                                    saved_count += 1
                            
                            if saved_count > 0:
                                st.success(f"Saved {saved_count} matches successfully!")
                            else:
                                st.error("Failed to save matches.")
                    else:
                        st.info("No matches found for this role.")
    
    with tab3:
        st.subheader("Auto Matching")
        
        # Banner explaining the feature
        st.markdown("""
        <div style="padding: 1rem; border-radius: 0.5rem; background-color: #f8f9fa; margin-bottom: 1.5rem;">
            <h5 style="color: #0050AA; margin-top: 0;">Automatic Employee-Role Matching</h5>
            <p style="margin-bottom: 0;">
                This feature automatically finds the best role for each employee based on their skills, experience, and qualifications.
                Use this to quickly identify optimal role assignments across your organization.
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        # Filter section
        st.markdown("### Filter Criteria")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Department filter
            departments = ["All"] + sorted(list(st.session_state.departments))
            auto_dept_filter = st.selectbox(
                "Department", 
                options=departments,
                key="auto_match_dept"
            )
            
            # Experience level filter
            experience_options = ["All", "Junior (0-2 years)", "Mid-level (3-5 years)", "Senior (6+ years)"]
            experience_filter = st.selectbox(
                "Experience Level",
                options=experience_options,
                key="auto_match_exp"
            )
        
        with col2:
            # Minimum match threshold
            match_threshold = st.slider(
                "Minimum Match Score",
                min_value=0,
                max_value=100,
                value=70,
                step=5,
                key="auto_match_threshold"
            ) / 100.0
            
            # Maximum results per employee
            max_roles = st.number_input(
                "Max Roles per Employee",
                min_value=1,
                max_value=10,
                value=3,
                step=1,
                key="auto_match_max_roles"
            )
        
        # Get filtered employees
        if len(st.session_state.employees) > 0:
            if auto_dept_filter != "All":
                filtered_employees = st.session_state.employees[st.session_state.employees['department'] == auto_dept_filter]
            else:
                filtered_employees = st.session_state.employees
            
            # Apply experience filter
            if experience_filter != "All":
                # Extract min-max experience from filter option
                if experience_filter == "Junior (0-2 years)":
                    min_exp, max_exp = 0, 2
                elif experience_filter == "Mid-level (3-5 years)":
                    min_exp, max_exp = 3, 5
                else:  # Senior
                    min_exp, max_exp = 6, float('inf')
                
                # Filter employees by experience
                filtered_employees = filtered_employees[
                    filtered_employees['experience'].apply(
                        lambda x: min_exp <= float(x if isinstance(x, (int, float)) else 0) <= max_exp
                    )
                ]
        else:
            st.error("No employees in the database. Please add employees first.")
            filtered_employees = pd.DataFrame()
        
        # Run auto matching when button is clicked
        if len(filtered_employees) > 0 and len(st.session_state.roles) > 0:
            if st.button("Run Automatic Matching", key="run_auto_match"):
                with st.spinner("Matching employees to optimal roles..."):
                    # Run matching for all employees against all roles
                    match_results = match_employees_to_roles(
                        employees=filtered_employees,
                        roles=st.session_state.roles,
                        top_n=int(max_roles)
                    )
                    
                    # Store results in session state
                    st.session_state.auto_match_results = match_results
                    
                    # Filter results by match threshold
                    for emp_id in match_results['employee_to_role']:
                        st.session_state.auto_match_results['employee_to_role'][emp_id] = [
                            match for match in match_results['employee_to_role'][emp_id] 
                            if match['overall_score'] >= match_threshold
                        ]
                    
                    st.success(f"Auto-matching complete for {len(filtered_employees)} employees!")
        else:
            if len(filtered_employees) == 0:
                st.warning("No employees match the selected filters.")
            if len(st.session_state.roles) == 0:
                st.error("No roles in the database. Please add roles first.")
        
        # Display auto-matching results if available
        if hasattr(st.session_state, 'auto_match_results'):
            st.markdown("### Best Role Matches for Each Employee")
            
            # Get employees with matches above threshold
            employees_with_matches = [
                emp_id for emp_id in st.session_state.auto_match_results['employee_to_role']
                if len(st.session_state.auto_match_results['employee_to_role'][emp_id]) > 0
            ]
            
            if len(employees_with_matches) > 0:
                # Create an expander for each employee
                for emp_id in employees_with_matches:
                    # Get employee name
                    employee_name = st.session_state.employees[
                        st.session_state.employees['employee_id'] == emp_id
                    ]['name'].values[0]
                    
                    # Get matches for this employee
                    emp_matches = st.session_state.auto_match_results['employee_to_role'][emp_id]
                    
                    # Create an expander with match count and top score
                    if len(emp_matches) > 0:
                        top_score = emp_matches[0]['overall_score'] * 100
                        expander_title = f"{employee_name} - {len(emp_matches)} matches (Top: {top_score:.1f}%)"
                        with st.expander(expander_title):
                            # Convert matches to DataFrame for display
                            matches_df = pd.DataFrame(emp_matches)
                            
                            # Format scores as percentages
                            score_cols = ['overall_score', 'skill_match', 'experience_match', 
                                        'certification_match', 'education_match']
                            for col in score_cols:
                                matches_df[col] = matches_df[col].apply(lambda x: f"{x*100:.1f}%")
                            
                            # Display matches as table
                            st.dataframe(
                                matches_df[['role_title', 'overall_score', 'skill_match', 
                                          'experience_match', 'certification_match', 'education_match']],
                                column_config={
                                    "role_title": "Role",
                                    "overall_score": "Overall Match",
                                    "skill_match": "Skills",
                                    "experience_match": "Experience",
                                    "certification_match": "Certifications",
                                    "education_match": "Education"
                                },
                                use_container_width=True,
                                hide_index=True
                            )
                            
                            # Option to view skill gaps for top match
                            if st.button("View Skill Gaps for Top Match", key=f"gaps_{emp_id}"):
                                top_match = emp_matches[0]
                                
                                # Display skill gaps
                                st.markdown("#### Skill Gap Analysis")
                                
                                missing_required = top_match['skill_gaps']['missing_required']
                                missing_preferred = top_match['skill_gaps']['missing_preferred']
                                
                                if len(missing_required) > 0 or len(missing_preferred) > 0:
                                    if len(missing_required) > 0:
                                        st.markdown("**Missing Required Skills:**")
                                        for skill in missing_required:
                                            st.markdown(f"- {skill}")
                                    
                                    if len(missing_preferred) > 0:
                                        st.markdown("**Missing Preferred Skills:**")
                                        for skill in missing_preferred:
                                            st.markdown(f"- {skill}")
                                    
                                    # Suggest development plan
                                    st.markdown("#### Suggested Development Actions")
                                    for skill in missing_required:
                                        st.markdown(f"- Prioritize training for **{skill}** (required skill)")
                                    
                                    if len(missing_preferred) > 0:
                                        preferred_to_show = min(3, len(missing_preferred))
                                        for skill in missing_preferred[:preferred_to_show]:
                                            st.markdown(f"- Consider developing **{skill}** to improve match")
                                else:
                                    st.success("No skill gaps identified for top match! The employee has all the required and preferred skills for this role.")
                            
                            # Option to save matches for this employee
                            if st.button(f"Save Matches for {employee_name}", key=f"save_emp_{emp_id}"):
                                saved_count = 0
                                for match in emp_matches:
                                    match_data = {
                                        'employee_id': emp_id,
                                        'role_id': match['role_id'],
                                        'match_score': float(match['overall_score'].strip('%'))/100 if isinstance(match['overall_score'], str) else match['overall_score'],
                                        'skill_match_score': float(match['skill_match'].strip('%'))/100 if isinstance(match['skill_match'], str) else match['skill_match'],
                                        'experience_match_score': float(match['experience_match'].strip('%'))/100 if isinstance(match['experience_match'], str) else match['experience_match'],
                                        'certification_match_score': float(match['certification_match'].strip('%'))/100 if isinstance(match['certification_match'], str) else match['certification_match'],
                                        'education_match_score': float(match['education_match'].strip('%'))/100 if isinstance(match['education_match'], str) else match['education_match'],
                                        'soft_skills_score': 0.5,  # Default value for auto-matching
                                        'notes': f"Auto-match: {employee_name} → {match['role_title']}"
                                    }
                                    
                                    match_id = add_match(match_data)
                                    if match_id:
                                        saved_count += 1
                                
                                if saved_count > 0:
                                    st.success(f"Saved {saved_count} matches for {employee_name}!")
                                else:
                                    st.error("Failed to save matches.")
                    
                # Add button to save all auto-matches
                if st.button("Save All Auto-Matches"):
                    total_saved = 0
                    for emp_id in employees_with_matches:
                        emp_matches = st.session_state.auto_match_results['employee_to_role'][emp_id]
                        # Only save top match for each employee to avoid cluttering the database
                        if len(emp_matches) > 0:
                            top_match = emp_matches[0]
                            employee_name = st.session_state.employees[
                                st.session_state.employees['employee_id'] == emp_id
                            ]['name'].values[0]
                            
                            match_data = {
                                'employee_id': emp_id,
                                'role_id': top_match['role_id'],
                                'match_score': float(top_match['overall_score'].strip('%'))/100 if isinstance(top_match['overall_score'], str) else top_match['overall_score'],
                                'skill_match_score': float(top_match['skill_match'].strip('%'))/100 if isinstance(top_match['skill_match'], str) else top_match['skill_match'],
                                'experience_match_score': float(top_match['experience_match'].strip('%'))/100 if isinstance(top_match['experience_match'], str) else top_match['experience_match'],
                                'certification_match_score': float(top_match['certification_match'].strip('%'))/100 if isinstance(top_match['certification_match'], str) else top_match['certification_match'],
                                'education_match_score': float(top_match['education_match'].strip('%'))/100 if isinstance(top_match['education_match'], str) else top_match['education_match'],
                                'soft_skills_score': 0.5,  # Default value for auto-matching
                                'notes': f"Auto-match (best fit): {employee_name} → {top_match['role_title']}"
                            }
                            
                            match_id = add_match(match_data)
                            if match_id:
                                total_saved += 1
                    
                    if total_saved > 0:
                        st.success(f"Saved top match for {total_saved} employees!")
                    else:
                        st.error("Failed to save matches.")
            else:
                st.warning("No matches above the threshold. Try lowering the minimum match score.")
                
                # Option to clear auto-match results and try again
                if st.button("Clear Results and Try Again"):
                    if hasattr(st.session_state, 'auto_match_results'):
                        del st.session_state.auto_match_results
                    st.rerun()
                
    with tab4:
        st.subheader("Match History")
        
        # Display match history if available
        if len(st.session_state.matches) > 0:
            # Select columns for display
            display_cols = ['match_id', 'employee_id', 'role_id', 'match_score', 'match_date']
            
            # Create a display dataframe
            display_df = st.session_state.matches[display_cols].copy()
            
            # Add employee and role names
            display_df['employee_name'] = display_df['employee_id'].apply(
                lambda x: st.session_state.employees[st.session_state.employees['employee_id']==x]['name'].values[0] 
                if len(st.session_state.employees[st.session_state.employees['employee_id']==x]) > 0 else 'Unknown'
            )
            
            display_df['role_title'] = display_df['role_id'].apply(
                lambda x: st.session_state.roles[st.session_state.roles['role_id']==x]['title'].values[0] 
                if len(st.session_state.roles[st.session_state.roles['role_id']==x]) > 0 else 'Unknown'
            )
            
            # Format match score as percentage
            display_df['match_score'] = display_df['match_score'].apply(lambda x: f"{x*100:.1f}%")
            
            # Rearrange columns for display
            display_order = ['match_id', 'employee_name', 'role_title', 'match_score', 'match_date']
            
            # Display the table
            st.dataframe(display_df[display_order], use_container_width=True)
            
            # Option to clear match history
            if st.button("Clear Match History"):
                if st.checkbox("Confirm clearing all match history"):
                    st.session_state.matches = pd.DataFrame(
                        columns=['match_id', 'employee_id', 'role_id', 'match_score', 
                                'skill_match_score', 'experience_match_score', 'certification_match_score',
                                'education_match_score', 'soft_skills_score', 'match_date', 'notes']
                    )
                    st.success("Match history cleared!")
                    st.rerun()
        else:
            st.info("No match history available. Run individual or batch matching to generate matches.")

# Run the page
skill_matching_page()
